Using GSON

Notes:
Option 1 Display User Calender does NOT count as a "changing" operation, and so does not prompt the client to save changes.
For my program, the events are sorted when they are displayed in Display User Calender, when the client add a new user, and when saving to the file. 

The main java file (entry point into the program) is CalenderDatabase.java